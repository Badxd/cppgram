#include "cppgram/client.h"
#include "cppgram/update_gate.h"
#include "cppgram/errors.h"
#include "cppgram/dc.h"
#include "cppgram/log.h"

#include <thread>
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <iterator>
#include <map>
#include <filesystem>
#include <set>
#include <mutex>
#include <fstream>
#include <iostream>
#include <stdexcept>

#include "cppgram/mtproto/auth.h"
#include "cppgram/mtproto/cancel.h"
#include "cppgram/session_string.h"
#include "cppgram/storage.h"
#include "cppgram/transfer.h"

#include <openssl/evp.h>

namespace cppgram {

namespace fn = mtproto::tl::functions;
namespace ty = mtproto::tl::types;
using mtproto::Bytes;
using mtproto::TlReader;
using mtproto::TlWriter;
namespace tl = mtproto::tl;

namespace {

constexpr std::int32_t kLayer = 233;
constexpr std::int32_t kDownloadChunk = 1024 * 1024;
constexpr int kMaxCdnReuploadsPerChunk = 3;

// Adapts a raw packet connection to the handshake's plain-message channel.
void debug_log(bool enabled, const std::string& message) {
    if (enabled) std::cerr << "[cppgram] " << message << "\n";
}

class PlainConnection : public mtproto::PlainChannel {
public:
    PlainConnection(mtproto::Connection& connection, bool debug) : connection_(connection), debug_(debug) {}

    // The handshake layer already wraps (auth_key_id=0, msg_id, length) and unwraps these packets,
    // so this adapter must pass them through untouched.
    void send_plain(const Bytes& packet) override {
        debug_log(debug_, "handshake: sending " + std::to_string(packet.size()) + " bytes");
        connection_.send_packet(packet);
    }

    Bytes receive_plain() override {
        Bytes packet = connection_.receive_packet();
        debug_log(debug_, "handshake: received " + std::to_string(packet.size()) + " bytes");
        return packet;
    }

private:
    mtproto::Connection& connection_;
    bool debug_;
};

std::int64_t random_i64() {
    const Bytes rnd = mtproto::random_bytes(8);
    return static_cast<std::int64_t>(mtproto::le_u64_from(rnd));
}

std::string to_hex(const Bytes& data) {
    static const char* digits = "0123456789abcdef";
    std::string out;
    out.reserve(data.size() * 2);
    for (const std::uint8_t b : data) {
        out.push_back(digits[b >> 4]);
        out.push_back(digits[b & 0x0f]);
    }
    return out;
}

// Incremental MD5 over the bytes of an upload, so the digest covers exactly what the server receives.
class Md5Stream {
public:
    Md5Stream() : ctx_(EVP_MD_CTX_new()) {
        if (ctx_ == nullptr || EVP_DigestInit_ex(ctx_, EVP_md5(), nullptr) != 1) {
            EVP_MD_CTX_free(ctx_);
            ctx_ = nullptr;
            throw std::runtime_error("cannot initialise MD5");
        }
    }
    ~Md5Stream() { EVP_MD_CTX_free(ctx_); }
    Md5Stream(const Md5Stream&) = delete;
    Md5Stream& operator=(const Md5Stream&) = delete;
    void update(const std::uint8_t* data, std::size_t len) {
        if (EVP_DigestUpdate(ctx_, data, len) != 1) throw std::runtime_error("MD5 update failed");
    }
    Bytes finish() {
        Bytes digest(EVP_MAX_MD_SIZE);
        unsigned int len = 0;
        if (EVP_DigestFinal_ex(ctx_, digest.data(), &len) != 1) throw std::runtime_error("MD5 finalisation failed");
        digest.resize(len);
        return digest;
    }

private:
    EVP_MD_CTX* ctx_ = nullptr;
};

std::string mime_for(const std::string& name) {
    const auto dot = name.rfind('.');
    std::string ext = dot == std::string::npos ? "" : name.substr(dot + 1);
    for (char& c : ext) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    if (ext == "jpg" || ext == "jpeg") return "image/jpeg";
    if (ext == "png") return "image/png";
    if (ext == "gif") return "image/gif";
    if (ext == "webp") return "image/webp";
    if (ext == "mp4") return "video/mp4";
    if (ext == "mp3") return "audio/mpeg";
    if (ext == "ogg" || ext == "oga") return "audio/ogg";
    if (ext == "pdf") return "application/pdf";
    if (ext == "txt") return "text/plain";
    if (ext == "json") return "application/json";
    return "application/octet-stream";
}

tl::InputPeer self_input_peer() {
    return tl::InputPeer{ty::inputPeerSelf{}};
}

}  // namespace

static double client_jitter01() {
    const mtproto::Bytes rnd = mtproto::random_bytes(8);
    return static_cast<double>(mtproto::le_u64_from(rnd)) / 18446744073709551615.0;
}

namespace detail {

ClientInstruments make_client_instruments(metrics::Registry* r) {
    ClientInstruments i;
    if (r == nullptr) return i;
    static const std::vector<double> kLatency{0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30};
    static const std::vector<double> kTransfer{0.1, 0.5, 1, 5, 15, 60, 300, 900, 3600};
    i.rpc_requests = r->counter("cppgram_rpc_requests_total", "MTProto RPC requests sent.").labels({});
    i.rpc_successes = r->counter("cppgram_rpc_successes_total", "MTProto RPC requests that returned a result.").labels({});
    i.rpc_failures = r->counter("cppgram_rpc_failures_total", "MTProto RPC requests that failed, by error category.", {"category"});
    i.rpc_latency = r->histogram("cppgram_rpc_latency_seconds", "MTProto RPC latency, including failed calls.", kLatency).labels({});
    i.connection_attempts = r->counter("cppgram_connection_attempts_total", "TCP connection attempts to the main DC, including retries.", {"dc_id"});
    i.connections = r->counter("cppgram_connections_total", "Sessions that finished connect (TCP, handshake and initConnection), by DC.", {"dc_id"});
    i.disconnects = r->counter("cppgram_disconnects_total", "Sessions that were connected and then disconnected.").labels({});
    i.reconnect_attempts = r->counter("cppgram_reconnect_attempts_total", "Reconnect attempts made after a dropped connection.").labels({});
    i.connected = r->gauge("cppgram_connected", "1 while the client session is ready, otherwise 0.").labels({});
    i.transport_errors = r->counter("cppgram_transport_errors_total", "Connect and transport failures, by error category.", {"category"});
    i.auth_failures = r->counter("cppgram_auth_failures_total", "Login attempts rejected by Telegram or refused by the state machine.").labels({});
    i.flood_waits = r->counter("cppgram_flood_wait_total", "FLOOD_WAIT responses received from Telegram.").labels({});
    i.upload_bytes = r->counter("cppgram_media_upload_bytes_total", "Bytes of files uploaded successfully.").labels({});
    i.part_retries = r->counter("cppgram_media_part_retries_total", "Upload or download parts retried after a transient failure.").labels({});
    i.download_bytes = r->counter("cppgram_media_download_bytes_total", "Bytes of media downloaded successfully.").labels({});
    auto transfer = [&](const char* direction) {
        TransferMetrics t;
        t.active = r->gauge("cppgram_media_active_transfers", "Media transfers in progress, by direction.", {"direction"}).labels({direction});
        t.failures = r->counter("cppgram_media_transfer_failures_total", "Media transfers that failed, by direction.", {"direction"}).labels({direction});
        t.seconds = r->histogram("cppgram_media_transfer_seconds", "Media transfer duration, by direction.", kTransfer, {"direction"}).labels({direction});
        return t;
    };
    i.upload = transfer("upload");
    i.download = transfer("download");
    return i;
}

} // namespace detail

namespace {

// Holds one active transfer: the active gauge is up while it lives, the duration is recorded at the end, and a
// failure is counted unless succeed() was called first.
class TransferScope {
public:
    explicit TransferScope(const TransferMetrics& m) : m_(m), started_(std::chrono::steady_clock::now()) {
        m_.active.add(1);
    }
    TransferScope(const TransferScope&) = delete;
    TransferScope& operator=(const TransferScope&) = delete;
    void succeed() noexcept { ok_ = true; }
    ~TransferScope() {
        m_.active.add(-1);
        m_.seconds.observe(detail::seconds_since(started_));
        if (!ok_) m_.failures.inc();
    }

private:
    const TransferMetrics& m_;
    std::chrono::steady_clock::time_point started_;
    bool ok_ = false;
};

} // namespace

Client::Client(ClientOptions options)
    : options_(std::move(options)), instruments_(detail::make_client_instruments(options_.metrics.get())) {}

Client::~Client() {
    // Cancel queued async work and wait for the running operation before anything else is torn down.
    runner_.reset();
    // Handlers may capture objects that the user has already destroyed or is destroying alongside the
    // client. Drop them before disconnect() so no user code runs during destruction.
    connection_handlers_.clear();
    auth_handlers_.clear();
    error_handlers_.clear();
    rpc_error_handlers_.clear();
    message_handlers_.clear();
    callback_handlers_.clear();
    raw_update_handlers_.clear();
    edited_handlers_.clear();
    member_handlers_.clear();
    join_handlers_.clear();
    deleted_handlers_.clear();
    inline_handlers_.clear();
    disconnect();
}

void Client::require_session() const {
    if (!session_) {
        throw std::runtime_error("client is not connected; call connect() first");
    }
}

void Client::connect() {
    // An explicit connect() starts a fresh session. A login code or 2FA challenge from before is no longer tracked.
    login_dc_ = 0;
    establish_connection();
}

void Client::establish_connection() {
    drop_connection();
    try {
        connect_impl();
    } catch (const std::exception& e) {
        log::write(log::Level::Error, "client", "connect failed",
                   {{"category", std::string(errors::to_string(errors::categorize(e)))}, {"reason", e.what()}});
        instruments_.transport_errors.labels({std::string(errors::to_string(errors::categorize(e)))}).inc();
        // A failed connect must not leave a half-open session behind: is_connected() would report true
        // for a session that cannot be used.
        drop_connection();
        throw;
    } catch (...) {
        drop_connection();
        throw;
    }
}

void Client::connect_impl() {
    set_auth_state(AuthState::Connecting);
    const bool debug = options_.debug;
    if (options_.socks5 && options_.mtproto_proxy) {
        set_auth_state(AuthState::Disconnected);
        throw std::invalid_argument("ClientOptions: socks5 and mtproto_proxy cannot be used together");
    }
    // Parse the proxy secret once, before any network activity. A malformed or unsupported secret is final.
    std::optional<mtproto::ProxySecret> proxy_secret;
    if (options_.mtproto_proxy) {
        proxy_secret = mtproto::parse_proxy_secret(options_.mtproto_proxy->secret);
        if (proxy_secret->kind == mtproto::ProxySecretKind::FakeTls) {
            set_auth_state(AuthState::Disconnected);
            throw std::invalid_argument("fake-TLS (ee) proxy secrets are not supported");
        }
    }
    const std::string& path = options_.session_path;
    const bool sqlite_path = path.ends_with(".sqlite") || path.ends_with(".sqlite3") || path.ends_with(".db");
    storage_.reset();
    if (sqlite_path) storage_ = std::make_unique<SqliteStorage>(path);

    mtproto::SessionData data;
    bool have_key = !force_new_auth_key_ &&
                    (sqlite_path ? storage_->load_session(data)
                                 : (mtproto::load_session_file(path, data) && data.auth_key.size() == 256));
    if (!have_key && !force_new_auth_key_ && !options_.session_string.empty()) {
        have_key = decode_session_string(options_.session_string, data);
        if (have_key) {
            if (sqlite_path) {
                storage_->save_session(data);
            } else {
                mtproto::save_session_file(path, data);
            }
            debug_log(debug, "session: restored from session_string");
        }
    }
    // A saved key belongs to the DC it was made on. Dial that DC, not the one in the options.
    if (have_key && data.dc_id != 0 && data.dc_id != options_.dc_id) {
        const DcEndpoint target = endpoint_for_dc(data.dc_id);
        debug_log(debug, "session: saved auth key belongs to DC " + std::to_string(data.dc_id) + ", dialling it");
        options_.dc_id = data.dc_id;
        options_.dc_ip = target.ip;
        options_.dc_port = static_cast<std::uint16_t>(target.port);
    }
    connection_ = std::make_unique<mtproto::Connection>(mtproto::TransportKind::Intermediate);
    connection_->set_connect_timeout(options_.connect_timeout_ms);
    if (options_.mtproto_proxy) {
        debug_log(debug, "tcp: connecting to MTProto proxy (dc " + std::to_string(options_.dc_id) + ")");
    } else {
        debug_log(debug, "tcp: connecting to " + options_.dc_ip + ":" + std::to_string(options_.dc_port) +
                             " (dc " + std::to_string(options_.dc_id) + ")");
    }
    // Connect with bounded retries. A refused or timed-out TCP connect is transient; the same connection
    // object cannot be reused after a failed connect, so each attempt gets a fresh Connection.
    mtproto::validate_retry_policy(options_.retry);
    for (int attempt = 1;; ++attempt) {
        try {
            instruments_.connection_attempts.labels({std::to_string(options_.dc_id)}).inc();
            if (options_.mtproto_proxy) {
                const auto& proxy = *options_.mtproto_proxy;
                connection_->set_connect_timeout(proxy.connect_timeout_ms);
                mtproto::ObfuscatedFraming framing = proxy_secret->kind == mtproto::ProxySecretKind::PaddedIntermediate
                                                         ? mtproto::ObfuscatedFraming::PaddedIntermediate
                                                         : mtproto::ObfuscatedFraming::Intermediate;
                switch (proxy.framing) {
                    case MtprotoProxyOptions::Framing::Auto: break;
                    case MtprotoProxyOptions::Framing::Intermediate:
                        framing = mtproto::ObfuscatedFraming::Intermediate;
                        break;
                    case MtprotoProxyOptions::Framing::PaddedIntermediate:
                        framing = mtproto::ObfuscatedFraming::PaddedIntermediate;
                        break;
                    case MtprotoProxyOptions::Framing::Abridged:
                        framing = mtproto::ObfuscatedFraming::Abridged;
                        break;
                }
                connection_->connect_obfuscated(proxy.host, proxy.port, *proxy_secret,
                                                static_cast<std::int16_t>(options_.dc_id),
                                                std::chrono::milliseconds(proxy.connect_timeout_ms), framing);
            } else if (options_.socks5) {
                connection_->connect_via_socks5(*options_.socks5, options_.dc_ip, options_.dc_port);
            } else {
                connection_->connect(options_.dc_ip, options_.dc_port);
            }
            break;
        } catch (const mtproto::ConnectionError& e) {
            // Rejected proxy credentials and refused targets are final; only transient failures are retried.
            const auto* proxy = dynamic_cast<const mtproto::ProxyError*>(&e);
            if (proxy != nullptr && !proxy->transient()) throw;
            if (!mtproto::may_retry(options_.retry, attempt)) throw;
            const auto delay = mtproto::backoff_delay(options_.retry, attempt, client_jitter01());
            debug_log(debug, std::string("tcp: connect failed (") + e.what() + "), retrying");
            log::write(log::Level::Warn, "client", "tcp connect failed, retrying",
                       {{"attempt", std::to_string(attempt)}, {"reason", e.what()}});
            mtproto::sleep_cancellable(std::chrono::duration_cast<std::chrono::milliseconds>(delay),
                                       current_stop_token());
            connection_ = std::make_unique<mtproto::Connection>(mtproto::TransportKind::Intermediate);
        }
    }
    debug_log(debug, "tcp: connected");
    log::write(log::Level::Info, "client", "tcp connected", {{"dc_id", std::to_string(options_.dc_id)}});
    connection_->set_receive_timeout(options_.connect_timeout_ms);

    if (!have_key) {
        debug_log(debug, "handshake: no saved auth key, creating one");
        PlainConnection plain(*connection_, debug);
        mtproto::HandshakeOptions handshake;
        handshake.dc_id = options_.dc_id;
        handshake.keys = options_.server_keys;
        const mtproto::AuthKeyResult key = mtproto::create_auth_key(plain, handshake);
        data.dc_id = options_.dc_id;
        data.auth_key = key.auth_key;
        data.server_salt = key.server_salt;
        data.time_offset = key.time_offset;
        if (sqlite_path) {
            storage_->save_session(data);
        } else {
            mtproto::save_session_file(path, data);
        }
        debug_log(debug, "handshake: auth key created and saved to " + path);
    } else {
        debug_log(debug, "session: reusing saved auth key from " + path);
    }
    force_new_auth_key_ = false;
    session_ = std::make_unique<mtproto::MtSession>(*connection_, data);
    {
        const auto flood = instruments_.flood_waits;
        session_->set_flood_wait_observer([flood](std::int32_t) { flood.inc(); });
    }
    session_->set_stop_token(current_stop_token());
    session_->set_retry_policy(options_.retry);
    session_->set_update_queue_limit(options_.max_pending_updates);
    connected_.store(true, std::memory_order_release);
    if (storage_) {
        if (const auto saved = storage_->load_state()) {
            state_.pts = saved->pts;
            state_.qts = saved->qts;
            state_.date = saved->date;
            state_.seq = saved->seq;
            state_.valid = true;
        }
    }

    // initConnection must wrap the first request of a session; help.getConfig is a cheap one.
    fn::invokeWithLayer<fn::initConnection<fn::help_getConfig>> init;
    init.layer = kLayer;
    init.query.api_id = options_.api_id;
    init.query.device_model = options_.device_model;
    init.query.system_version = options_.system_version;
    init.query.app_version = options_.app_version;
    init.query.system_lang_code = options_.lang_code;
    init.query.lang_code = options_.lang_code;
    const tl::Config cfg = call_rpc(init);
    dc_endpoints_.clear();
    if (const auto* c = std::get_if<ty::config>(&cfg.value)) {
        for (const auto& opt : c->dc_options) {
            if (!opt) continue;
            const auto* o = std::get_if<ty::dcOption>(&opt->value);
            if (o == nullptr || o->ipv6 || o->secret) continue;
            dc_endpoints_.push_back(DcEndpoint{o->id, o->ip_address, o->port, o->cdn});
        }
    }
    connection_->set_receive_timeout(0);
    set_auth_state(AuthState::Unauthenticated);  // authorization is unknown until probe_session()
    notify_connection(ConnectionEvent::Connected);
    debug_log(debug, "session: initConnection done");
    log::write(log::Level::Info, "client", "session initialised");
    instruments_.connections.labels({std::to_string(options_.dc_id)}).inc();
    instruments_.connected.set(1);
}

void Client::disconnect() {
    // An explicit disconnect ends the login in progress. Nothing from it may be reused after a later connect().
    login_dc_ = 0;
    drop_connection();
}

void Client::drop_connection() {
    const bool was_connected = session_ != nullptr;
    set_auth_state(AuthState::Disconnected);
    connected_.store(false, std::memory_order_release);
    session_.reset();
    if (was_connected) log::write(log::Level::Info, "client", "disconnected");
    if (was_connected) instruments_.disconnects.inc();
    instruments_.connected.set(0);
    if (was_connected) notify_connection(ConnectionEvent::Disconnected);
    if (connection_) {
        connection_->close();
        connection_.reset();
    }
}

Client::DcEndpoint Client::endpoint_for_dc(std::int32_t dc_id) const {
    for (const auto& a : options_.dc_addresses) {
        if (a.id == dc_id) return DcEndpoint{dc_id, a.ip, static_cast<std::int32_t>(a.port), false};
    }
    for (const auto& e : dc_endpoints_) {
        if (e.id == dc_id && !e.cdn) return e;
    }
    const std::string builtin = dc_address(dc_id);
    if (!builtin.empty()) return DcEndpoint{dc_id, builtin, 443, false};
    throw std::runtime_error("no address known for DC " + std::to_string(dc_id));
}

void Client::migrate_to_dc(std::int32_t dc_id) {
    // An unknown DC throws here, before anything changes: the connection and the login state stay as they were.
    const DcEndpoint target = endpoint_for_dc(dc_id);
    log::write(log::Level::Info, "client", "migrating to home DC", {{"dc_id", std::to_string(dc_id)}});
    // A login step in progress is kept across the move. Its phone code or 2FA challenge belongs to the DC the
    // connection left (login_dc_), and the login steps return there when they need it. connect_impl() would
    // otherwise reset the state to Unauthenticated. Any other state is reset as before.
    const AuthState before = auth_state_;
    const bool keep_login = before == AuthState::CodeRequired || before == AuthState::PasswordRequired ||
                            before == AuthState::Authenticating;
    const auto prev_dc = options_.dc_id;
    const auto prev_ip = options_.dc_ip;
    const auto prev_port = options_.dc_port;
    options_.dc_id = dc_id;
    options_.dc_ip = target.ip;
    options_.dc_port = static_cast<std::uint16_t>(target.port);
    force_new_auth_key_ = true;
    try {
        // Drops the old session, then performs a new handshake on the new DC and saves the new key.
        establish_connection();
    } catch (...) {
        // A failed hop must leave a consistent state. The new key was not saved, so the saved session still belongs to
        // the previous DC. The previous DC settings come back, so a later connect() dials that DC again. The pending
        // code is not known to be usable any more, so the login is cleared.
        options_.dc_id = prev_dc;
        options_.dc_ip = prev_ip;
        options_.dc_port = prev_port;
        force_new_auth_key_ = false;
        login_dc_ = 0;
        log::write(log::Level::Warn, "client", "migration failed; previous DC settings restored",
                   {{"dc_id", std::to_string(dc_id)}});
        throw;
    }
    if (keep_login) set_auth_state(before);
}

void Client::login_bot(const std::string& bot_token) {
    require_session();
    fn::auth_importBotAuthorization req;
    req.flags = 0;
    req.api_id = options_.api_id;
    req.api_hash = options_.api_hash;
    req.bot_auth_token = bot_token;
    log::write(log::Level::Info, "client", "bot login requested");
    // A bot account lives on one DC. Telegram answers USER_MIGRATE_N on the wrong DC and does not process the
    // request, so repeating it on DC N is safe. The number of hops is bounded.
    constexpr int kMaxMigrations = 2;
    for (int migrations = 0;; ++migrations) {
        try {
            call_rpc(req);
            break;
        } catch (const mtproto::RpcError& e) {
            const int dc = migrate_dc_from_error(e.rpc_message());
            if (dc == 0 || migrations >= kMaxMigrations) throw;
            migrate_to_dc(dc);
        }
    }
    log::write(log::Level::Info, "client", "bot login accepted");
    // The session now belongs to the bot account, so a phone login that was pending ends here.
    login_dc_ = 0;
    if (auth_state_ == AuthState::CodeRequired || auth_state_ == AuthState::PasswordRequired) {
        set_auth_state(AuthState::Unauthenticated);
    }
    if (auth_state_ == AuthState::Unauthenticated) apply_auth_event(AuthEvent::SessionRestored);
    sync_updates_state();
}

void Client::cache_users_chats(const std::vector<std::shared_ptr<tl::User>>& users,
                               const std::vector<std::shared_ptr<tl::Chat>>& chats) {
    cache_.add_users(users);
    cache_.add_chats(chats);
}

User Client::get_me() {
    require_session();
    fn::users_getUsers req;
    req.id = {std::make_shared<tl::InputUser>(tl::InputUser{ty::inputUserSelf{}})};
    const auto users = call_rpc(req);
    cache_users_chats(users, {});
    for (const auto& u : users) {
        if (u) {
            if (auto me = detail::user_from_tl(*u); me && me->is_self) {
                return *me;
            }
        }
    }
    throw std::runtime_error("users.getUsers did not return the current user");
}

void Client::on_message(Filter filter, MessageHandler handler, int group) {
    message_handlers_.push_back(MessageRoute{group, std::move(filter), std::move(handler)});
    std::stable_sort(message_handlers_.begin(), message_handlers_.end(),
                     [](const MessageRoute& a, const MessageRoute& b) { return a.group < b.group; });
}

void Client::on_error(ErrorHandler handler) {
    error_handlers_.push_back(std::move(handler));
}

void Client::on_connection_state(ConnectionHandler handler) {
    connection_handlers_.push_back(std::move(handler));
}

void Client::on_auth_state(AuthStateHandler handler) {
    auth_handlers_.push_back(std::move(handler));
}

void Client::on_rpc_error(RpcErrorHandler handler) {
    rpc_error_handlers_.push_back(std::move(handler));
}

void Client::notify_rpc_error(std::int32_t code, const std::string& name) {
    // Copy the list: a handler may register another handler while we iterate.
    const auto handlers = rpc_error_handlers_;
    for (const auto& h : handlers) {
        try {
            h(*this, code, name);
        } catch (const std::exception& e) {
            report_handler_error("rpc error handler", e);
        }
    }
}

void Client::notify_connection(ConnectionEvent event) {
    const auto handlers = connection_handlers_;
    for (const auto& h : handlers) {
        try {
            h(*this, event);
        } catch (const std::exception& e) {
            report_handler_error("connection handler", e);
        }
    }
}

void Client::set_auth_state(AuthState next) {
    if (next == auth_state_) return;
    auth_state_ = next;
    const auto handlers = auth_handlers_;
    for (const auto& h : handlers) {
        try {
            h(*this, next);
        } catch (const std::exception& e) {
            report_handler_error("auth state handler", e);
        }
    }
}

void Client::report_handler_error(const std::string& stage, const std::exception& e) {
    log::write(log::Level::Error, "client", "handler failed", {{"stage", stage}, {"reason", e.what()}});
    if (error_handlers_.empty()) {
        std::cerr << "cppgram: " << stage << " failed: " << e.what() << "\n";
        return;
    }
    for (auto& handler : error_handlers_) {
        try {
            handler(*this, stage, e.what());
        } catch (const std::exception& inner) {
            std::cerr << "cppgram: error handler failed: " << inner.what() << "\n";
        }
    }
}

void Client::on_callback_query(CallbackHandler handler) {
    callback_handlers_.push_back(std::move(handler));
}

void Client::dispatch_message(const Message& message) {
    // Handlers run group by group. Within a group every matching handler runs, in insertion order.
    for (auto& route : message_handlers_) {
        if (!route.filter(message)) continue;
        try {
            route.handler(*this, message);
        } catch (const std::exception& e) {
            report_handler_error("message handler", e);
        }
    }
}

namespace {

std::int64_t channel_id_of_message(const mtproto::tl::Message& message) {
    const auto* m = std::get_if<ty::message>(&message.value);
    if (!m || !m->peer_id) return 0;
    if (const auto* ch = std::get_if<ty::peerChannel>(&m->peer_id->value)) return ch->channel_id;
    return 0;
}

}  // namespace

void Client::handle_update(const tl::Update& update) {
    // Account-wide updates are gated by the common pts. Channel updates use their own per-channel pts.
    if (const auto* nm = std::get_if<ty::updateNewMessage>(&update.value)) {
        if (!accept_pts(nm->pts, nm->pts_count)) return;
    } else if (const auto* em = std::get_if<ty::updateEditMessage>(&update.value)) {
        if (!accept_pts(em->pts, em->pts_count)) return;
    } else if (const auto* dm = std::get_if<ty::updateDeleteMessages>(&update.value)) {
        if (!accept_pts(dm->pts, dm->pts_count)) return;
    } else if (const auto* ncm = std::get_if<ty::updateNewChannelMessage>(&update.value)) {
        const std::int64_t channel = ncm->message ? channel_id_of_message(*ncm->message) : 0;
        if (!accept_channel_pts(channel, ncm->pts, ncm->pts_count)) return;
    } else if (const auto* ecm = std::get_if<ty::updateEditChannelMessage>(&update.value)) {
        const std::int64_t channel = ecm->message ? channel_id_of_message(*ecm->message) : 0;
        if (!accept_channel_pts(channel, ecm->pts, ecm->pts_count)) return;
    } else if (const auto* dcm = std::get_if<ty::updateDeleteChannelMessages>(&update.value)) {
        if (!accept_channel_pts(dcm->channel_id, dcm->pts, dcm->pts_count)) return;
    }
    dispatch_update_unchecked(update);
}

bool Client::accept_channel_pts(std::int64_t channel_id, std::int32_t pts, std::int32_t pts_count) {
    if (channel_id == 0) return true;  // no channel attached: nothing to gate
    if (!channel_pts_.pts(channel_id)) {
        // No baseline yet: trust this update and start tracking from the state it implies.
        channel_pts_.set_baseline(channel_id, pts - pts_count);
    }
    switch (channel_pts_.classify(channel_id, pts, pts_count)) {
        case PtsDecision::Apply:
            channel_pts_.mark_applied(channel_id, pts);
            return true;
        case PtsDecision::Duplicate:
            return false;
        case PtsDecision::Gap:
            // getChannelDifference re-delivers the missing updates, so this one is dropped.
            catch_up_channel(channel_id);
            return false;
    }
    return false;
}

void Client::catch_up_channel(std::int64_t channel_id) {
    require_session();
    const auto base = channel_pts_.pts(channel_id);
    const auto peer = cache_.find(PeerKind::Channel, channel_id);
    if (!base || !peer || !peer->has_access_hash) {
        // Without an access hash the channel cannot be queried. Forget it so the next update re-baselines.
        channel_pts_.forget(channel_id);
        return;
    }
    for (;;) {
        fn::updates_getChannelDifference req;
        req.force = false;
        req.channel = std::make_shared<tl::InputChannel>(tl::InputChannel{ty::inputChannel{peer->id, peer->access_hash}});
        req.filter = std::make_shared<tl::ChannelMessagesFilter>(tl::ChannelMessagesFilter{ty::channelMessagesFilterEmpty{}});
        req.pts = channel_pts_.pts(channel_id).value_or(0);
        req.limit = 100;
        const tl::updates_ChannelDifference diff = invoke(req);

        if (const auto* empty = std::get_if<ty::updates_channelDifferenceEmpty>(&diff.value)) {
            channel_pts_.set_baseline(channel_id, empty->pts);
            return;
        }
        if (std::get_if<ty::updates_channelDifferenceTooLong>(&diff.value)) {
            // Server dropped history for this channel. The next update re-baselines from its own pts.
            channel_pts_.forget(channel_id);
            return;
        }
        const auto& d = std::get<ty::updates_channelDifference>(diff.value);
        cache_users_chats(d.users, d.chats);
        for (const auto& m : d.new_messages) {
            if (!m) continue;
            if (auto msg = detail::message_from_tl(*m, cache_)) dispatch_message(*msg);
        }
        for (const auto& up : d.other_updates) if (up) dispatch_update_unchecked(*up);

        const auto previous = channel_pts_.pts(channel_id).value_or(0);
        channel_pts_.set_baseline(channel_id, d.pts);
        // Stop when final, or when the server did not move the channel forward (avoids a loop).
        if (d.final_ || d.pts <= previous) return;
    }
}

bool Client::accept_pts(std::int32_t pts, std::int32_t pts_count) {
    if (!state_.valid) return true;
    switch (classify_pts(state_.pts, pts, pts_count)) {
        case PtsDecision::Apply:
            state_.pts = pts;
            persist_state();
            return true;
        case PtsDecision::Duplicate:
            return false;
        case PtsDecision::Gap:
            // Some updates were missed. getDifference returns them, so drop this one.
            catch_up();
            return false;
    }
    return false;
}

void Client::apply_update_state(const tl::updates_State& state) {
    const auto& s = std::get<ty::updates_state>(state.value);
    state_.pts = s.pts;
    state_.qts = s.qts;
    state_.date = s.date;
    state_.seq = s.seq;
    state_.valid = true;
    persist_state();
}

void Client::persist_state() {
    if (!storage_ || !state_.valid) return;
    storage_->save_state(StoredUpdateState{state_.pts, state_.qts, state_.date, state_.seq});
}

void Client::sync_updates_state() {
    require_session();
    fn::updates_getState req;
    const tl::updates_State st = invoke(req);
    apply_update_state(st);
}

void Client::catch_up() {
    require_session();
    if (!state_.valid) {
        sync_updates_state();
        return;
    }
    // Each slice moves the state forward; the loop ends on differenceEmpty or a final difference.
    for (;;) {
        fn::updates_getDifference req;
        req.pts = state_.pts;
        req.date = state_.date;
        req.qts = state_.qts;
        const tl::updates_Difference diff = invoke(req);

        if (const auto* empty = std::get_if<ty::updates_differenceEmpty>(&diff.value)) {
            state_.date = empty->date;
            state_.seq = empty->seq;
            state_.valid = true;
            persist_state();
            return;
        }
        if (std::get_if<ty::updates_differenceTooLong>(&diff.value)) {
            // Server dropped too much history: take the current state and continue from there.
            const auto& tl_long = std::get<ty::updates_differenceTooLong>(diff.value);
            state_.pts = tl_long.pts;
            state_.valid = true;
            sync_updates_state();
            continue;
        }
        if (const auto* d = std::get_if<ty::updates_difference>(&diff.value)) {
            cache_users_chats(d->users, d->chats);
            for (const auto& m : d->new_messages) {
                if (!m) continue;
                if (auto msg = detail::message_from_tl(*m, cache_)) dispatch_message(*msg);
            }
            for (const auto& up : d->other_updates) if (up) dispatch_update_unchecked(*up);
            if (d->state) apply_update_state(*d->state);
            return;
        }
        const auto& slice = std::get<ty::updates_differenceSlice>(diff.value);
        cache_users_chats(slice.users, slice.chats);
        for (const auto& m : slice.new_messages) {
            if (!m) continue;
            if (auto msg = detail::message_from_tl(*m, cache_)) dispatch_message(*msg);
        }
        for (const auto& up : slice.other_updates) if (up) dispatch_update_unchecked(*up);
        if (slice.intermediate_state) apply_update_state(*slice.intermediate_state);
    }
}

void Client::dispatch_update_unchecked(const tl::Update& update) {
    handle_membership_update(update);
    for (auto& handler : raw_update_handlers_) {
        try {
            handler(*this, update);
        } catch (const std::exception& e) {
            report_handler_error("raw update handler", e);
        }
    }
    if (const auto* nm = std::get_if<ty::updateNewMessage>(&update.value)) {
        if (nm->message) {
            if (auto msg = detail::message_from_tl(*nm->message, cache_)) dispatch_message(*msg);
        }
    } else if (const auto* ncm = std::get_if<ty::updateNewChannelMessage>(&update.value)) {
        if (ncm->message) {
            if (auto msg = detail::message_from_tl(*ncm->message, cache_)) dispatch_message(*msg);
        }
    } else if (const auto* em = std::get_if<ty::updateEditMessage>(&update.value)) {
        if (em->message) {
            if (auto msg = detail::message_from_tl(*em->message, cache_)) {
                for (auto& handler : edited_handlers_) {
                    try { handler(*this, *msg); } catch (const std::exception& e) {
                        report_handler_error("edited message handler", e);
                    }
                }
            }
        }
    } else if (const auto* ecm = std::get_if<ty::updateEditChannelMessage>(&update.value)) {
        if (ecm->message) {
            if (auto msg = detail::message_from_tl(*ecm->message, cache_)) {
                for (auto& handler : edited_handlers_) {
                    try { handler(*this, *msg); } catch (const std::exception& e) {
                        report_handler_error("edited message handler", e);
                    }
                }
            }
        }
    } else if (const auto* iq = std::get_if<ty::updateBotInlineQuery>(&update.value)) {
        InlineQuery query;
        query.id = iq->query_id;
        query.user_id = iq->user_id;
        query.query = iq->query;
        query.offset = iq->offset;
        for (auto& handler : inline_handlers_) {
            try { handler(*this, query); } catch (const std::exception& e) {
                report_handler_error("inline query handler", e);
            }
        }
    } else if (const auto* cb = std::get_if<ty::updateBotCallbackQuery>(&update.value)) {
        CallbackQuery query;
        query.id = cb->query_id;
        query.user_id = cb->user_id;
        query.message_id = cb->msg_id;
        if (cb->data) query.data.assign(cb->data->begin(), cb->data->end());
        if (cb->peer) query.chat = detail::peer_from_tl(*cb->peer, cache_);
        for (auto& handler : callback_handlers_) {
            try {
                handler(*this, query);
            } catch (const std::exception& e) {
                report_handler_error("callback handler", e);
            }
        }
    }
}

void Client::handle_update_body(const Bytes& body) {
    TlReader r(body);
    const std::uint32_t id = r.read_uint32();
    switch (id) {
        case ty::updateShortMessage::kId: {
            const ty::updateShortMessage m = ty::updateShortMessage::read_body(r);
            if (!accept_pts(m.pts, m.pts_count)) return;
            PeerRef chat;
            chat.kind = PeerKind::User;
            chat.id = m.user_id;
            if (const auto known = cache_.find(PeerKind::User, m.user_id)) chat = *known;
            PeerRef sender = chat;
            if (m.out) sender = PeerRef{PeerKind::User, cache_.self_id(), 0, false};
            dispatch_message(detail::short_message(m.id, chat, sender, m.message, m.date, m.out));
            return;
        }
        case ty::updateShortChatMessage::kId: {
            const ty::updateShortChatMessage m = ty::updateShortChatMessage::read_body(r);
            if (!accept_pts(m.pts, m.pts_count)) return;
            PeerRef chat{PeerKind::Chat, m.chat_id, 0, false};
            PeerRef sender{PeerKind::User, m.from_id, 0, false};
            if (const auto known = cache_.find(PeerKind::User, m.from_id)) sender = *known;
            dispatch_message(detail::short_message(m.id, chat, sender, m.message, m.date, m.out));
            return;
        }
        case ty::updateShort::kId: {
            const ty::updateShort s = ty::updateShort::read_body(r);
            if (s.update) handle_update(*s.update);
            return;
        }
        case ty::updates::kId: {
            const ty::updates u = ty::updates::read_body(r);
            cache_users_chats(u.users, u.chats);
            for (const auto& up : u.updates) if (up) handle_update(*up);
            return;
        }
        case ty::updatesCombined::kId: {
            const ty::updatesCombined u = ty::updatesCombined::read_body(r);
            cache_users_chats(u.users, u.chats);
            for (const auto& up : u.updates) if (up) handle_update(*up);
            return;
        }
        case ty::updatesTooLong::kId:
            catch_up();
            return;
        default:
            return;
    }
}

void Client::drain_updates() {
    if (!session_) return;
    for (const Bytes& body : session_->take_updates()) {
        try {
            handle_update_body(body);
        } catch (const std::exception& e) {
            std::cerr << "cppgram: failed to process update: " << e.what() << "\n";
            log::write(log::Level::Warn, "client", "update processing failed", {{"reason", e.what()}});
        }
    }
}

void Client::ping() {
    fn::ping_delay_disconnect req;
    req.ping_id = random_i64();
    req.disconnect_delay = 75;
    TlWriter w;
    req.serialize(w);
    session_->send_content(w.bytes());
}

void Client::reconnect_after_drop() {
    // connect() resets the authorization state, so remember it and check the key again afterwards.
    const bool was_authorized = auth_state_ == AuthState::Authorized;
    notify_connection(ConnectionEvent::Reconnecting);
    log::write(log::Level::Warn, "client", "connection dropped, reconnecting",
               {{"was_authorized", was_authorized ? "true" : "false"}});
    for (;;) {
        if (!reconnect_budget_.record_failure()) {
            log::write(log::Level::Error, "client", "reconnect budget exhausted",
                       {{"max_reconnects", std::to_string(options_.max_reconnects)}});
            throw mtproto::ConnectionError("gave up reconnecting after " + std::to_string(options_.max_reconnects) +
                                           " failed attempts");
        }
        instruments_.reconnect_attempts.inc();
        connected_.store(false, std::memory_order_release);
        session_.reset();
        if (connection_) {
            connection_->close();
            connection_.reset();
        }
        mtproto::sleep_cancellable(
            mtproto::backoff_delay(options_.retry, reconnect_budget_.failures, client_jitter01()),
            current_stop_token());
        try {
            connect();
            connection_->set_receive_timeout(options_.keepalive_ms);
            if (was_authorized) probe_session();  // AuthRevoked/AuthExpired is recorded in auth_state()
            catch_up();  // recover updates missed while disconnected
            // The outage is over. Start the next outage with a full budget: a quiet connection may never
            // complete a process_one(), so the budget would otherwise never reset between drops.
            reconnect_budget_.reset();
            return;
        } catch (const mtproto::ConnectionError&) {
            // Still down: loop, which spends one more unit of the budget.
        }
    }
}

void Client::prepare_session_tokens() {
    std::stop_token operation;
    {
        std::lock_guard<std::mutex> lock(stop_mutex_);
        if (op_token_) operation = *op_token_;
    }
    session_->set_stop_token(current_stop_token());
    session_->set_cancel_token(std::move(operation));
}

std::stop_token Client::current_stop_token() {
    std::lock_guard<std::mutex> lock(stop_mutex_);
    if (op_token_) return *op_token_;
    return stop_source_.get_token();
}

async::AsyncResult<void> Client::connect_async(std::stop_token stop) {
    auto result = async([](Client& client, std::stop_token) { client.connect(); });
    result.link(std::move(stop));
    return result;
}

async::AsyncResult<void> Client::disconnect_async() {
    return async([](Client& client, std::stop_token) { client.disconnect(); });
}

async::AsyncResult<void> Client::login_bot_async(std::string bot_token, std::stop_token stop) {
    auto result = async([token = std::move(bot_token)](Client& client, std::stop_token) { client.login_bot(token); });
    result.link(std::move(stop));
    return result;
}

void Client::run() {
    require_session();
    // A new run starts unstopped; stop() from an earlier run no longer applies. The new source and running_ = true are
    // set under the same lock stop() takes. Otherwise a stop() that landed between the two could be overwritten by
    // running_ = true, and the loop would run without a stop request.
    {
        std::lock_guard<std::mutex> lock(stop_mutex_);
        stop_source_ = std::stop_source{};
        running_ = true;
    }
    prepare_session_tokens();
    // Restored state (SQLite session) means updates may have been missed while offline.
    if (storage_ && state_.valid) catch_up();
    connection_->set_receive_timeout(options_.keepalive_ms);
    try {
        reconnect_budget_ = mtproto::ReconnectBudget{options_.max_reconnects, 0};
        while (running_) {
            drain_updates();
            // Backpressure: do not read more packets while the update queue is at its limit.
            while (session_->update_queue_full()) drain_updates();
            try {
                session_->process_one();
                reconnect_budget_.reset();
            } catch (const mtproto::ConnectionTimeout&) {
                ping();
            } catch (const mtproto::ConnectionError&) {
                if (!options_.auto_reconnect) throw;
                reconnect_after_drop();
            }
        }
        drain_updates();
    } catch (const mtproto::OperationCancelled&) {
        // stop() interrupted a backoff: a clean exit, not an error.
        if (connection_) connection_->set_receive_timeout(0);
        running_ = false;
        return;
    } catch (...) {
        if (connection_) connection_->set_receive_timeout(0);
        running_ = false;
        throw;
    }
    if (connection_) connection_->set_receive_timeout(0);
    running_ = false;
}

namespace {

// Accepts "@name", "name", "https://t.me/name", "t.me/name?start=x", and returns the bare reference.
std::string strip_reference(std::string ref) {
    while (!ref.empty() && std::isspace(static_cast<unsigned char>(ref.front()))) ref.erase(0, 1);
    while (!ref.empty() && std::isspace(static_cast<unsigned char>(ref.back()))) ref.pop_back();
    for (const char* prefix : {"https://t.me/", "http://t.me/", "t.me/", "https://telegram.me/", "telegram.me/"}) {
        const std::string p(prefix);
        if (ref.rfind(p, 0) == 0) {
            ref.erase(0, p.size());
            break;
        }
    }
    if (!ref.empty() && ref[0] == '@') ref.erase(0, 1);
    return ref;
}

bool all_digits(const std::string& s) {
    return !s.empty() && std::all_of(s.begin(), s.end(), [](unsigned char c) { return std::isdigit(c) != 0; });
}

std::string lowercase(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return s;
}

}  // namespace

PeerRef Client::resolve(const std::string& reference) {
    require_session();
    std::string ref = strip_reference(reference);
    if (ref.empty()) throw std::invalid_argument("resolve: empty reference");

    if (ref == "me" || ref == "self") {
        if (cache_.self_id() == 0) get_me();
        const auto self = cache_.find(PeerKind::User, cache_.self_id());
        return self.value_or(PeerRef{PeerKind::User, cache_.self_id(), 0, false});
    }

    // Message links to private channels: t.me/c/<channel id>/<message id>.
    if (ref.rfind("c/", 0) == 0) {
        const std::size_t end = ref.find('/', 2);
        const std::string id = ref.substr(2, end == std::string::npos ? std::string::npos : end - 2);
        if (!all_digits(id)) throw std::invalid_argument("resolve: bad channel link " + reference);
        ref = "-100" + id;
    }

    // Numeric references: -100<id> channel, -<id> basic group, <id> user (must already be cached).
    const bool negative = ref.size() > 1 && ref[0] == '-';
    const std::string digits = negative ? ref.substr(1) : ref;
    if (all_digits(digits)) {
        if (negative) {
            if (digits.size() > 3 && digits.rfind("100", 0) == 0) {
                const std::int64_t id = std::stoll(digits.substr(3));
                if (auto known = cache_.find(PeerKind::Channel, id)) return *known;
                throw std::runtime_error("channel " + ref + " is not cached; resolve it by username or invite link first");
            }
            return PeerRef{PeerKind::Chat, std::stoll(digits), 0, false};
        }
        const std::int64_t id = std::stoll(digits);
        if (auto known = cache_.find(PeerKind::User, id)) return *known;
        throw std::runtime_error("user " + ref + " is not cached; resolve it by username first");
    }

    // Usernames are case-insensitive and may be followed by "/..." or "?..." in links.
    const std::size_t cut = ref.find_first_of("/?");
    const std::string name = lowercase(cut == std::string::npos ? ref : ref.substr(0, cut));
    if (auto known = cache_.find_username(name)) return *known;

    fn::contacts_resolveUsername req;
    req.username = name;
    const tl::contacts_ResolvedPeer resolved = call_rpc(req);
    const auto* rp = std::get_if<ty::contacts_resolvedPeer>(&resolved.value);
    if (rp == nullptr || !rp->peer) {
        throw std::runtime_error("username not found: " + name);
    }
    cache_users_chats(rp->users, rp->chats);
    return detail::peer_from_tl(*rp->peer, cache_);
}

tl::InputPeer Client::input_peer(const PeerRef& peer) const {
    switch (peer.kind) {
        case PeerKind::User:
            if (peer.id == cache_.self_id()) return self_input_peer();
            if (!peer.has_access_hash) {
                throw std::runtime_error("user access hash unknown; resolve the user first");
            }
            return tl::InputPeer{ty::inputPeerUser{peer.id, peer.access_hash}};
        case PeerKind::Chat:
            return tl::InputPeer{ty::inputPeerChat{peer.id}};
        case PeerKind::Channel:
            if (!peer.has_access_hash) {
                throw std::runtime_error("channel access hash unknown; resolve the channel first");
            }
            return tl::InputPeer{ty::inputPeerChannel{peer.id, peer.access_hash}};
    }
    throw std::runtime_error("unknown peer kind");
}

std::vector<Message> Client::collect_messages(const tl::messages_Messages& result) {
    std::vector<Message> out;
    std::visit(
        [&](const auto& v) {
            if constexpr (requires { v.users; v.chats; v.messages; }) {
                cache_users_chats(v.users, v.chats);
                for (const auto& m : v.messages) {
                    if (!m) continue;
                    if (auto msg = detail::message_from_tl(*m, cache_)) out.push_back(*msg);
                }
            }
        },
        result.value);
    return out;
}

std::optional<Message> Client::find_sent_message(const tl::Updates& updates, const PeerRef& target,
                                                 const std::string& text, std::int32_t fallback_id) {
    if (const auto* s = std::get_if<ty::updateShortSentMessage>(&updates.value)) {
        return detail::short_message(s->id, target, PeerRef{PeerKind::User, cache_.self_id(), 0, false}, text,
                                     s->date, true);
    }
    const std::vector<std::shared_ptr<tl::Update>>* list = nullptr;
    if (const auto* u = std::get_if<ty::updates>(&updates.value)) {
        cache_users_chats(u->users, u->chats);
        list = &u->updates;
    } else if (const auto* c = std::get_if<ty::updatesCombined>(&updates.value)) {
        cache_users_chats(c->users, c->chats);
        list = &c->updates;
    }
    if (list != nullptr) {
        for (const auto& up : *list) {
            if (!up) continue;
            const tl::Message* raw = nullptr;
            if (const auto* nm = std::get_if<ty::updateNewMessage>(&up->value)) raw = nm->message.get();
            else if (const auto* ncm = std::get_if<ty::updateNewChannelMessage>(&up->value)) raw = ncm->message.get();
            if (raw != nullptr) {
                if (auto msg = detail::message_from_tl(*raw, cache_)) return msg;
            }
        }
    }
    if (fallback_id != 0) {
        return detail::short_message(fallback_id, target, std::nullopt, text, 0, true);
    }
    return std::nullopt;
}

Message Client::send_message(const std::string& target, const std::string& text,
                             std::optional<std::int32_t> reply_to_id) {
    return send_message(resolve(target), text, reply_to_id);
}

Message Client::send_message(const PeerRef& target, const std::string& text,
                             std::optional<std::int32_t> reply_to_id, std::optional<std::int64_t> effect_id) {
    require_session();
    fn::messages_sendMessage req;
    req.peer = std::make_shared<tl::InputPeer>(input_peer(target));
    req.message = text;
    req.random_id = random_i64();
    if (reply_to_id) {
        req.reply_to = std::make_shared<tl::InputReplyTo>(tl::InputReplyTo{ty::inputReplyToMessage{*reply_to_id}});
    }
    req.effect = effect_id;
    const tl::Updates updates = call_rpc(req);
    if (auto msg = find_sent_message(updates, target, text, 0)) {
        return *msg;
    }
    throw std::runtime_error("message was sent but no id was returned by the server");
}

Message Client::edit_message(const PeerRef& target, std::int32_t message_id, const std::string& text) {
    require_session();
    fn::messages_editMessage req;
    req.peer = std::make_shared<tl::InputPeer>(input_peer(target));
    req.id = message_id;
    req.message = text;
    const tl::Updates updates = call_rpc(req);
    if (auto msg = find_sent_message(updates, target, text, message_id)) {
        return *msg;
    }
    return detail::short_message(message_id, target, std::nullopt, text, 0, true);
}

void Client::delete_messages(const PeerRef& target, const std::vector<std::int32_t>& message_ids, bool revoke) {
    require_session();
    if (target.kind == PeerKind::Channel) {
        fn::channels_deleteMessages req;
        req.channel = std::make_shared<tl::InputChannel>(tl::InputChannel{ty::inputChannel{target.id, target.access_hash}});
        req.id = message_ids;
        call_rpc(req);
        return;
    }
    fn::messages_deleteMessages req;
    req.revoke = revoke;
    req.id = message_ids;
    call_rpc(req);
}

std::vector<Message> Client::get_messages(const PeerRef& target, const std::vector<std::int32_t>& message_ids) {
    require_session();
    if (target.kind == PeerKind::Channel) {
        fn::channels_getMessages req;
        req.channel = std::make_shared<tl::InputChannel>(tl::InputChannel{ty::inputChannel{target.id, target.access_hash}});
        for (const auto id : message_ids) {
            req.id.push_back(std::make_shared<tl::InputMessage>(tl::InputMessage{ty::inputMessageID{id}}));
        }
        return collect_messages(call_rpc(req));
    }
    fn::messages_getMessages req;
    for (const auto id : message_ids) {
        req.id.push_back(std::make_shared<tl::InputMessage>(tl::InputMessage{ty::inputMessageID{id}}));
    }
    return collect_messages(call_rpc(req));
}

std::vector<Message> Client::get_history(const PeerRef& target, std::int32_t limit, std::int32_t offset_id) {
    require_session();
    fn::messages_getHistory req;
    req.peer = std::make_shared<tl::InputPeer>(input_peer(target));
    req.offset_id = offset_id;
    req.limit = limit;
    return collect_messages(call_rpc(req));
}

void Client::send_chat_action(const PeerRef& target, ChatAction action) {
    require_session();
    fn::messages_setTyping req;
    req.peer = std::make_shared<tl::InputPeer>(input_peer(target));
    switch (action) {
        case ChatAction::Typing: req.action = std::make_shared<tl::SendMessageAction>(tl::SendMessageAction{ty::sendMessageTypingAction{}}); break;
        case ChatAction::Cancel: req.action = std::make_shared<tl::SendMessageAction>(tl::SendMessageAction{ty::sendMessageCancelAction{}}); break;
        case ChatAction::UploadPhoto: req.action = std::make_shared<tl::SendMessageAction>(tl::SendMessageAction{ty::sendMessageUploadPhotoAction{0}}); break;
        case ChatAction::UploadVideo: req.action = std::make_shared<tl::SendMessageAction>(tl::SendMessageAction{ty::sendMessageUploadVideoAction{0}}); break;
        case ChatAction::UploadDocument: req.action = std::make_shared<tl::SendMessageAction>(tl::SendMessageAction{ty::sendMessageUploadDocumentAction{0}}); break;
        case ChatAction::RecordVoice: req.action = std::make_shared<tl::SendMessageAction>(tl::SendMessageAction{ty::sendMessageRecordAudioAction{}}); break;
        case ChatAction::RecordVideo: req.action = std::make_shared<tl::SendMessageAction>(tl::SendMessageAction{ty::sendMessageRecordRoundAction{}}); break;
    }
    call_rpc(req);
}

void Client::pin_message(const PeerRef& target, std::int32_t message_id, bool silent) {
    require_session();
    fn::messages_updatePinnedMessage req;
    req.peer = std::make_shared<tl::InputPeer>(input_peer(target));
    req.id = message_id;
    req.silent = silent;
    req.unpin = false;
    call_rpc(req);
}

void Client::unpin_message(const PeerRef& target, std::int32_t message_id) {
    require_session();
    fn::messages_updatePinnedMessage req;
    req.peer = std::make_shared<tl::InputPeer>(input_peer(target));
    req.id = message_id;
    req.unpin = true;
    call_rpc(req);
}

std::vector<Message> Client::forward_messages(const PeerRef& from, const PeerRef& to,
                                              const std::vector<std::int32_t>& message_ids) {
    require_session();
    fn::messages_forwardMessages req;
    req.from_peer = std::make_shared<tl::InputPeer>(input_peer(from));
    req.to_peer = std::make_shared<tl::InputPeer>(input_peer(to));
    req.id = message_ids;
    for (std::size_t i = 0; i < message_ids.size(); ++i) {
        req.random_id.push_back(random_i64());
    }
    const tl::Updates updates = call_rpc(req);
    std::vector<Message> out;
    if (const auto* u = std::get_if<ty::updates>(&updates.value)) {
        for (const auto& up : u->updates) {
            if (!up) continue;
            if (const auto* nm = std::get_if<ty::updateNewMessage>(&up->value)) {
                if (nm->message) if (auto msg = detail::message_from_tl(*nm->message, cache_)) out.push_back(*msg);
            } else if (const auto* ncm = std::get_if<ty::updateNewChannelMessage>(&up->value)) {
                if (ncm->message) if (auto msg = detail::message_from_tl(*ncm->message, cache_)) out.push_back(*msg);
            }
        }
    }
    return out;
}

void Client::answer_callback_query(std::int64_t query_id, const std::string& text, bool alert, const std::string& url) {
    require_session();
    fn::messages_setBotCallbackAnswer req;
    req.query_id = query_id;
    req.alert = alert;
    if (!text.empty()) req.message = text;
    if (!url.empty()) req.url = url;
    call_rpc(req);
}

// Part-level helpers for media transfers.
bool Client::retryable_part_error(const std::exception& e) {
    if (const auto* rpc = dynamic_cast<const mtproto::RpcError*>(&e)) {
        return rpc->code() >= 500 && rpc->code() < 600;
    }
    const auto category = errors::categorize(e);
    return category == errors::Category::Network || category == errors::Category::Timeout;
}

bool Client::connection_lost(const std::exception& e) {
    const auto category = errors::categorize(e);
    return category == errors::Category::Network || category == errors::Category::Timeout;
}

void Client::sleep_part_backoff(int attempt) {
    const auto delay = mtproto::backoff_delay(options_.retry, attempt, client_jitter01());
    mtproto::sleep_cancellable(std::chrono::duration_cast<std::chrono::milliseconds>(delay), current_stop_token());
}

mtproto::tl::upload_File Client::fetch_file_part(const mtproto::tl::functions::upload_getFile& req) {
    try {
        return call_with_part_retry(req);
    } catch (const mtproto::RpcError& e) {
        if (e.rpc_message().find("FILE_REFERENCE_EXPIRED") != std::string::npos) {
            throw errors::FileTransferError("file reference expired; fetch the message again to get a new reference");
        }
        throw;
    }
}

std::shared_ptr<tl::InputFile> Client::upload(const std::string& path, std::string& out_name, std::int64_t& out_size,
                                              const UploadProgress& progress) {
    TransferScope transfer(instruments_.upload);
    // The size is checked before the file is opened, so empty and over-limit files fail early.
    std::error_code ec;
    const auto file_size = std::filesystem::file_size(path, ec);
    if (ec) throw errors::FileTransferError("cannot read file size: " + path);
    UploadPlan plan;
    try {
        plan = plan_upload(file_size, options_.upload_part_size);
    } catch (const std::exception& e) {
        throw errors::FileTransferError(std::string("upload rejected for ") + path + ": " + e.what());
    }
    std::ifstream in(path, std::ios::binary);
    if (!in) throw errors::FileTransferError("cannot open file: " + path);
    out_name = std::filesystem::path(path).filename().string();
    out_size = static_cast<std::int64_t>(file_size);
    const bool big = plan.big_file;
    const std::int64_t file_id = random_i64();
    const std::uint32_t parts = plan.part_count;
    // One pass over the file. Each part is hashed as it is read, so the MD5 sent with inputFile covers exactly the
    // bytes the server receives, and the file is never read twice.
    Md5Stream md5;
    Bytes chunk;
    std::uint64_t sent = 0;
    for (std::uint32_t i = 0; i < parts; ++i) {
        if (current_stop_token().stop_requested()) throw errors::CancelledError("upload cancelled: " + path);
        const std::uint64_t off = upload_part_offset(plan, i);
        const std::size_t len = static_cast<std::size_t>(std::min<std::uint64_t>(plan.part_size, file_size - off));
        chunk.resize(len);
        in.read(reinterpret_cast<char*>(chunk.data()), static_cast<std::streamsize>(len));
        if (static_cast<std::size_t>(in.gcount()) != len) {
            throw errors::FileTransferError("file changed while uploading: " + path);
        }
        if (!big) md5.update(chunk.data(), len);
        bool stored = false;
        if (big) {
            fn::upload_saveBigFilePart req;
            req.file_id = file_id;
            req.file_part = static_cast<std::int32_t>(i);
            req.file_total_parts = static_cast<std::int32_t>(parts);
            req.bytes = std::move(chunk);
            stored = call_with_part_retry(req);
        } else {
            fn::upload_saveFilePart req;
            req.file_id = file_id;
            req.file_part = static_cast<std::int32_t>(i);
            req.bytes = std::move(chunk);
            stored = call_with_part_retry(req);
        }
        if (!stored) {
            throw errors::FileTransferError("server did not store upload part " + std::to_string(i) + " of " + path);
        }
        sent += len;
        if (progress) progress(static_cast<std::int64_t>(sent), static_cast<std::int64_t>(file_size));
    }
    // The file must still have the size it had when the plan was made.
    std::error_code size_ec;
    const auto now_size = std::filesystem::file_size(path, size_ec);
    if (size_ec || now_size != file_size || sent != file_size) {
        throw errors::FileTransferError("file changed while uploading: " + path);
    }
    transfer.succeed();
    instruments_.upload_bytes.inc(static_cast<double>(sent));
    auto file = std::make_shared<tl::InputFile>();
    if (big) {
        *file = tl::InputFile{ty::inputFileBig{file_id, static_cast<std::int32_t>(parts), out_name}};
    } else {
        *file = tl::InputFile{ty::inputFile{file_id, static_cast<std::int32_t>(parts), out_name, to_hex(md5.finish())}};
    }
    return file;
}

std::string download_fingerprint(const Message& message) {
    return "cppgram-part-v1 kind=" + std::to_string(static_cast<int>(message.media.kind)) +
           " id=" + std::to_string(message.media.id) + " size=" + std::to_string(message.media.size);
}

Message Client::send_media(const PeerRef& target, std::shared_ptr<tl::InputMedia> media, const std::string& caption) {
    require_session();
    fn::messages_sendMedia req;
    req.peer = std::make_shared<tl::InputPeer>(input_peer(target));
    req.media = std::move(media);
    req.message = caption;
    req.random_id = random_i64();
    const tl::Updates updates = call_rpc(req);
    if (auto msg = find_sent_message(updates, target, caption, 0)) {
        return *msg;
    }
    throw std::runtime_error("media was sent but no message was returned by the server");
}

Message Client::send_document(const PeerRef& target, const std::string& path, const std::string& caption) {
    std::string name;
    std::int64_t size = 0;
    auto file = upload(path, name, size, UploadProgress{});
    ty::inputMediaUploadedDocument doc;
    doc.file = file;
    doc.force_file = true;
    doc.mime_type = mime_for(name);
    doc.attributes.push_back(std::make_shared<tl::DocumentAttribute>(tl::DocumentAttribute{ty::documentAttributeFilename{name}}));
    return send_media(target, std::make_shared<tl::InputMedia>(tl::InputMedia{doc}), caption);
}

Message Client::send_photo(const PeerRef& target, const std::string& path, const std::string& caption) {
    std::string name;
    std::int64_t size = 0;
    auto file = upload(path, name, size, UploadProgress{});
    ty::inputMediaUploadedPhoto photo;
    photo.file = file;
    return send_media(target, std::make_shared<tl::InputMedia>(tl::InputMedia{photo}), caption);
}

std::int64_t Client::download_media(const Message& message, const std::string& path) {
    return download_media(message, path, DownloadProgress{});
}

namespace {

// Destination partial files that a download in this process is writing. Two downloads to the same partial file
// would interleave their bytes and metadata, so the second one is refused instead.
class DownloadLease {
public:
    explicit DownloadLease(std::string temp_path) : key_(std::move(temp_path)) {
        std::lock_guard<std::mutex> lock(mutex());
        if (!active().insert(key_).second) {
            throw errors::FileTransferError("another download is already writing " + key_);
        }
    }
    ~DownloadLease() {
        std::lock_guard<std::mutex> lock(mutex());
        active().erase(key_);
    }
    DownloadLease(const DownloadLease&) = delete;
    DownloadLease& operator=(const DownloadLease&) = delete;

private:
    static std::mutex& mutex() {
        static std::mutex m;
        return m;
    }
    static std::set<std::string>& active() {
        static std::set<std::string> s;
        return s;
    }
    std::string key_;
};

}  // namespace

std::int64_t Client::download_media(const Message& message, const std::string& path, DownloadProgress progress) {
    TransferScope transfer(instruments_.download);
    require_session();
    std::shared_ptr<tl::InputFileLocation> location;
    if (message.media.kind == MediaKind::Photo) {
        location = std::make_shared<tl::InputFileLocation>(tl::InputFileLocation{ty::inputPhotoFileLocation{
            message.media.id, message.media.access_hash, message.media.file_reference, "y"}});
    } else if (message.media.kind == MediaKind::Document) {
        location = std::make_shared<tl::InputFileLocation>(tl::InputFileLocation{ty::inputDocumentFileLocation{
            message.media.id, message.media.access_hash, message.media.file_reference, ""}});
    } else {
        throw std::runtime_error("message has no downloadable media");
    }
    // Data goes to "<path>.part" and is renamed to path only after the size checks pass. A failed or
    // interrupted download leaves no partial file at the destination; the .part file is removed.
    // The .part file is kept after a failure so the next call resumes from its last aligned chunk. It is
    // trusted by size only: Telegram gives no hash for these files, so delete it if the file on the server changed.
    const std::string temp_path = path + ".part";
    const std::string meta_path = temp_path + ".meta";
    std::error_code abs_ec;
    const std::string lease_key = std::filesystem::absolute(temp_path, abs_ec).string();
    DownloadLease lease(abs_ec ? temp_path : lease_key);
    const std::string fingerprint = download_fingerprint(message);
    std::int64_t offset = 0;
    {
        // A partial file is resumed only when its sidecar names this same media. A partial without a matching
        // sidecar cannot be validated, so it is discarded and the download starts again.
        std::error_code ec;
        const bool partial_exists = std::filesystem::exists(temp_path, ec);
        bool same_media = false;
        if (partial_exists) {
            std::ifstream meta_in(meta_path, std::ios::binary);
            const std::string stored((std::istreambuf_iterator<char>(meta_in)), std::istreambuf_iterator<char>());
            same_media = stored == fingerprint;
        }
        if (partial_exists && same_media) {
            const auto partial = std::filesystem::file_size(temp_path, ec);
            if (!ec) {
                const std::uint64_t resume =
                    resume_offset(partial, static_cast<std::uint64_t>(std::max<std::int64_t>(0, message.media.size)),
                                  static_cast<std::uint32_t>(kDownloadChunk));
                if (resume > 0) {
                    std::filesystem::resize_file(temp_path, resume, ec);
                    if (ec) throw errors::FileTransferError("cannot prepare resume of " + temp_path + ": " + ec.message());
                    offset = static_cast<std::int64_t>(resume);
                }
            }
        } else if (partial_exists) {
            std::filesystem::remove(temp_path, ec);
        }
        std::ofstream meta_out(meta_path, std::ios::binary | std::ios::trunc);
        meta_out << fingerprint;
        meta_out.flush();
        if (!meta_out) throw errors::FileTransferError("cannot write " + meta_path);
    }

    std::int64_t total = 0;
    {
        std::ofstream out(temp_path, std::ios::binary | (offset > 0 ? std::ios::app : std::ios::trunc));
        if (!out) {
            throw errors::FileTransferError("cannot open for writing: " + temp_path);
        }
        for (;;) {
            if (current_stop_token().stop_requested()) throw errors::CancelledError("download cancelled: " + path);
            fn::upload_getFile req;
            req.location = location;
            req.offset = offset;
            req.limit = kDownloadChunk;
            req.cdn_supported = true;
            const tl::upload_File file = fetch_file_part(req);
            const auto* f = std::get_if<ty::upload_file>(&file.value);
            if (f == nullptr) {
                const auto* redirect = std::get_if<ty::upload_fileCdnRedirect>(&file.value);
                if (redirect == nullptr) throw std::runtime_error("upload.getFile returned an unexpected type");
                offset += download_via_cdn(*redirect, out);
                break;
            }
            out.write(reinterpret_cast<const char*>(f->bytes.data()), static_cast<std::streamsize>(f->bytes.size()));
            if (!out) throw errors::FileTransferError("write failed while downloading to " + temp_path);
            offset += static_cast<std::int64_t>(f->bytes.size());
            if (progress) progress(offset, message.media.size);
            if (f->bytes.size() < static_cast<std::size_t>(kDownloadChunk)) break;
        }
        out.flush();
        if (!out) throw errors::FileTransferError("write failed while downloading to " + temp_path);
        total = offset;
    }
    if (message.media.size > 0 && total != message.media.size) {
        // Wrong size cannot be resumed from safely, so the partial file is discarded.
        std::error_code ignored;
        std::filesystem::remove(temp_path, ignored);
        std::filesystem::remove(meta_path, ignored);
        throw errors::FileTransferError("download size mismatch: received " + std::to_string(total) + " bytes, expected " +
                                 std::to_string(message.media.size));
    }
    std::error_code ec;
    std::filesystem::rename(temp_path, path, ec);
    if (ec) throw errors::FileTransferError("cannot move download into place: " + ec.message());
    std::error_code meta_ec;
    std::filesystem::remove(meta_path, meta_ec);
    if (progress) progress(total, message.media.size);
    transfer.succeed();
    instruments_.download_bytes.inc(static_cast<double>(total));
    return total;
}

std::int64_t Client::download_via_cdn(const ty::upload_fileCdnRedirect& redirect, std::ofstream& out) {
    const DcEndpoint* endpoint = nullptr;
    for (const auto& e : dc_endpoints_) {
        if (e.id == redirect.dc_id && e.cdn) endpoint = &e;
    }
    if (endpoint == nullptr) {
        for (const auto& e : dc_endpoints_) {
            if (e.id == redirect.dc_id) endpoint = &e;
        }
    }
    if (endpoint == nullptr) {
        throw std::runtime_error("no address known for CDN DC " + std::to_string(redirect.dc_id));
    }
    debug_log(options_.debug, "cdn: connecting to DC " + std::to_string(redirect.dc_id) + " at " + endpoint->ip);
    mtproto::Connection cdn_conn(mtproto::TransportKind::Intermediate);
    cdn_conn.connect(endpoint->ip, static_cast<std::uint16_t>(endpoint->port));
    cdn_conn.set_receive_timeout(options_.connect_timeout_ms);
    PlainConnection plain(cdn_conn, options_.debug);
    mtproto::HandshakeOptions handshake;
    handshake.dc_id = redirect.dc_id;
    handshake.keys = options_.server_keys;
    const mtproto::AuthKeyResult key = mtproto::create_auth_key(plain, handshake);
    mtproto::SessionData data;
    data.dc_id = redirect.dc_id;
    data.auth_key = key.auth_key;
    data.server_salt = key.server_salt;
    data.time_offset = key.time_offset;
    cdn_conn.set_receive_timeout(options_.connect_timeout_ms);
    mtproto::MtSession cdn(cdn_conn, data);

    // SHA-256 of each encrypted part, keyed by its offset. Parts are checked before they are decrypted and written.
    std::map<std::int64_t, std::pair<std::int32_t, Bytes>> hashes;
    for (const auto& h : redirect.file_hashes) {
        if (h) if (const auto* fh = std::get_if<ty::fileHash>(&h->value)) hashes[fh->offset] = {fh->limit, fh->hash};
    }
    auto verify_chunk = [&](std::int64_t start, const Bytes& enc) {
        const std::int64_t end = start + static_cast<std::int64_t>(enc.size());
        std::int64_t p = start;
        while (p < end) {
            auto it = hashes.find(p);
            if (it == hashes.end()) {
                fn::upload_getCdnFileHashes hreq;
                hreq.file_token = redirect.file_token;
                hreq.offset = p;
                const std::vector<std::shared_ptr<tl::FileHash>> fetched = call_rpc(hreq);
                for (const auto& h : fetched) {
                    if (h) if (const auto* fh = std::get_if<ty::fileHash>(&h->value)) hashes[fh->offset] = {fh->limit, fh->hash};
                }
                it = hashes.find(p);
                if (it == hashes.end()) {
                    throw std::runtime_error("no CDN hash for file part at offset " + std::to_string(p));
                }
            }
            const std::int64_t len = it->second.first;
            if (len <= 0 || p + len > end) {
                throw std::runtime_error("CDN hash part at offset " + std::to_string(p) + " does not line up with the chunk");
            }
            const Bytes part(enc.begin() + (p - start), enc.begin() + (p - start + len));
            if (mtproto::sha256(part) != it->second.second) {
                throw std::runtime_error("CDN part at offset " + std::to_string(p) + " failed its SHA-256 check");
            }
            p += len;
        }
    };

    std::int64_t offset = 0;
    int reuploads_for_chunk = 0;
    for (;;) {
        fn::upload_getCdnFile req;
        req.file_token = redirect.file_token;
        req.offset = offset;
        req.limit = kDownloadChunk;
        const tl::upload_CdnFile chunk = cdn.call(req);
        const auto* cf = std::get_if<ty::upload_cdnFile>(&chunk.value);
        if (cf == nullptr) {
            // The CDN no longer holds this file and asks for it to be reuploaded. upload.reuploadCdnFile is sent on
            // the main DC connection. The hashes it returns replace the old ones, then the same chunk is requested again.
            const auto* need = std::get_if<ty::upload_cdnFileReuploadNeeded>(&chunk.value);
            if (need == nullptr || reuploads_for_chunk >= kMaxCdnReuploadsPerChunk) {
                throw std::runtime_error("CDN file at offset " + std::to_string(offset) + " could not be recovered after "
                                         + std::to_string(reuploads_for_chunk) + " reupload request(s)");
            }
            ++reuploads_for_chunk;
            fn::upload_reuploadCdnFile reupload;
            reupload.file_token = redirect.file_token;
            reupload.request_token = need->request_token;
            const std::vector<std::shared_ptr<tl::FileHash>> fresh = call_rpc(reupload);
            for (const auto& h : fresh) {
                if (h) if (const auto* fh = std::get_if<ty::fileHash>(&h->value)) hashes[fh->offset] = {fh->limit, fh->hash};
            }
            debug_log(options_.debug, "cdn: reuploaded file hashes at offset " + std::to_string(offset));
            continue;
        }
        reuploads_for_chunk = 0;
        if (options_.verify_cdn_hashes) verify_chunk(offset, cf->bytes);
        const Bytes plain_bytes = mtproto::aes_ctr_crypt(cf->bytes, redirect.encryption_key,
                                                         mtproto::cdn_counter_iv(redirect.encryption_iv, offset));
        out.write(reinterpret_cast<const char*>(plain_bytes.data()), static_cast<std::streamsize>(plain_bytes.size()));
        offset += static_cast<std::int64_t>(plain_bytes.size());
        if (plain_bytes.size() < static_cast<std::size_t>(kDownloadChunk)) break;
    }
    cdn_conn.close();
    return offset;
}

void Client::join_chat_by_invite(const std::string& invite_hash) {
    require_session();
    fn::messages_importChatInvite req;
    req.hash = invite_hash;
    call_rpc(req);
}

void Client::join_channel(const PeerRef& channel) {
    require_session();
    fn::channels_joinChannel req;
    req.channel = std::make_shared<tl::InputChannel>(tl::InputChannel{ty::inputChannel{channel.id, channel.access_hash}});
    call_rpc(req);
}

void Client::leave_channel(const PeerRef& channel) {
    require_session();
    fn::channels_leaveChannel req;
    req.channel = std::make_shared<tl::InputChannel>(tl::InputChannel{ty::inputChannel{channel.id, channel.access_hash}});
    call_rpc(req);
}

}  // namespace cppgram

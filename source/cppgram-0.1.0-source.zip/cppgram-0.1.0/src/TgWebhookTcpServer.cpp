#include <utility>

#include "cppgram/bot/TgWebhookTcpServer.h"

namespace cppgram::bot {

TgWebhookTcpServer::TgWebhookTcpServer(unsigned short port, std::string path, const EventHandler& eventHandler)
    : TgWebhookServer(boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), port), std::move(path), eventHandler) {
}

TgWebhookTcpServer::TgWebhookTcpServer(unsigned short port, const Bot& bot)
    : TgWebhookServer(boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), port), bot) {
}

} // namespace cppgram::bot

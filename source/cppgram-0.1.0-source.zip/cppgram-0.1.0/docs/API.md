# Public API overview

The public API is in `include/cppgram/`. Every `Client` member is listed in [`API_INDEX.md`](API_INDEX.md), which
`tools/api_index.py` generates from `include/cppgram/client.h`. Run `python3 tools/api_index.py --check` after you change
the header. Do not edit `API_INDEX.md` by hand.

## Main parts

| Header | What it provides |
|---|---|
| `cppgram/client.h` | `cppgram::Client`: connect, sign in (bot token, phone code, 2FA, QR), calls to Telegram methods, updates, `run()` and `stop()` |
| `cppgram/types.h`, `cppgram/convert.h` | Typed wrappers for users, chats, messages and media, and their conversion from TL objects |
| `cppgram/filters.h`, `cppgram/parser.h` | Update filters and text parsing |
| `cppgram/async.h`, `cppgram/task.h` | Running client calls asynchronously; `Client::async` |
| `cppgram/errors.h` | Typed errors in `cppgram::errors`, derived from `errors::Error` |
| `cppgram/log.h` | Structured logging with levels, components, request ids and secret redaction. Default level WARN |
| `cppgram/metrics.h`, `cppgram/metrics_prometheus.h` | Counters and gauges, and a Prometheus text exporter |
| `cppgram/session_string.h`, `cppgram/session_crypto.h` | Session export and import, and encrypted session files (`CGE1`) |
| `cppgram/storage.h` | Session storage |
| `cppgram/webapp.h` | Verification of Web App `initData` (HMAC-SHA256, constant-time comparison, time window) |
| `cppgram/transfer.h` | Uploads and downloads with progress |
| `cppgram/qr_login.h`, `cppgram/auth_state.h` | QR login and the login state machine |
| `cppgram/dc.h` | Data-centre addresses and migration parsing |
| `cppgram/update_gate.h`, `cppgram/channel_pts.h` | Update ordering and channel state |
| `cppgram/mtproto/` | Lower layers: crypto, TL, transports, handshake, connection, session, proxies |
| `cppgram/bot.h`, `cppgram/bot/` | Bot API layer (HTTP, long polling, webhooks, JSON types) |

## Stability

Version 0.1.0 is a pre-release. Until 1.0.0 a minor version may change the public API. `CHANGELOG.md` records changes.

## Examples

`examples/` contains programs that are compile-checked by `tools/check_examples.sh`. They are not run by the build.
Live programs are described in [`../LIVE_TESTING.md`](../LIVE_TESTING.md).

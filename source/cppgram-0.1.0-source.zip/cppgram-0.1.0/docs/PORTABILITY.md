# Platform and portability

## Verified for this release

| Platform | Compiler | Build | Tests | Evidence |
|---|---|---|---|---|
| Linux x86_64 (Ubuntu 24.04) | GCC 13.3.0, C++20, Release | PASS | `ctest`: 710 of 710 | `logs/gcc-build.log`, `logs/ctest-gcc.log` |
| Linux x86_64 (Ubuntu 24.04) | Clang 18.1.3, C++20, Release | PASS | `ctest`: 710 of 710 | `logs/clang-build.log`, `logs/ctest-clang.log` |

## Not verified for this release

- **ARM64 (aarch64).** CI job `build-arm64` runs on `ubuntu-24.04-arm`. No ARM64 machine or cross compiler was available
  here, so ARM64 is NOT RUN.
- **Windows.** Not supported.
- **macOS.** Not tested.
- **Shared libraries** (`BUILD_SHARED_LIBS=ON`). Not part of this verification.

## Dependencies

OpenSSL, zlib, SQLite 3, libcurl, Boost (headers only), nlohmann/json and GoogleTest (tests only). Versions used: see
`BUILD_RESULTS.md`.

## Install and consumers

`cmake --install <build> --prefix <dir>` installs headers, `libcppgram.a` and CMake package files. A consumer project that
uses `find_package(cppgram CONFIG REQUIRED)` and links `cppgram::cppgram` was configured and built against an installed
copy for this release (see `BUILD_RESULTS.md`).

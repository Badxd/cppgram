# Benchmarks

Status for this release: **NOT RUN.** The numbers in older reports came from an earlier build and were not measured
again, so do not quote them for this release.

## How to run

```sh
cmake -S . -B build/bench -DCMAKE_BUILD_TYPE=Release -DENABLE_BENCHMARKS=ON
cmake --build build/bench --target cppgram_bench
./build/bench/cppgram_bench
```

The benchmark measures local work only (encoding, framing, crypto, the metrics and async paths on loopback). It does not
contact Telegram. `bench/runtime_bench.cpp` covers the runtime paths. `tools/run_benchmarks.sh` wraps the run.
